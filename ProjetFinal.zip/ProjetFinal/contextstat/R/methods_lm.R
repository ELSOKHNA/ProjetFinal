
print.context_lm <- function(x, ...) {
  
  cat("============================================\n")
  cat("   Régression linéaire avec contexte\n")
  cat("============================================\n\n")
  
  if (!is.null(x$context)) {
    cat("Contexte :\n")
    cat("  ", x$context, "\n\n")
  }
  
  cat("Formule :\n")
  cat("  ", deparse(x$formula), "\n\n")
  
  cat("Résultats :\n")
  cat("-----------\n")
  print(x$summary)
  
  cat("\n============================================\n")
  cat("   Interprétation contextuelle (LLM)\n")
  cat("============================================\n\n")
  cat(strwrap(x$interpretation, width = 70), sep = "\n")
  cat("\n============================================\n")
  
  invisible(x)
}



summary.context_lm <- function(object, ...) {
  cat("=== Résumé de la régression linéaire ===\n\n")
  cat("Contexte:", object$context, "\n\n")
  print(object$summary)
  cat("\n--- Interprétation LLM ---\n")
  cat(object$interpretation, "\n")
  invisible(object)
}


