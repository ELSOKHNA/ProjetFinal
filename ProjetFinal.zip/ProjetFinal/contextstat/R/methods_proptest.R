
print.context_proptest <- function(x, ...) {
  
  cat("============================================\n")
  cat("   Test de proportion avec contexte\n")
  cat("============================================\n\n")
  
  # Contexte
  if (!is.null(x$context)) {
    cat("Contexte :\n")
    cat("  ", x$context, "\n\n")
  }
  
  # Résultats statistiques
  cat("Résultats du test :\n")
  cat("-------------------\n")
  cat(sprintf("  Nombre d'essais (n)       : %d\n", x$n))
  cat(sprintf("  Nombre de succès (x)      : %d\n", x$x))
  cat(sprintf("  Proportion observée       : %.2f%% (%.4f)\n",
              x$prop_estimee * 100, x$prop_estimee))
  cat(sprintf("  Hypothèse nulle (p0)      : %.2f%%\n", x$p0 * 100))
  cat(sprintf("  Niveau de confiance       : %.0f%%\n", x$conf_level * 100))
  cat(sprintf("  Intervalle de confiance   : [%.4f, %.4f]\n",
              x$ic_inf, x$ic_sup))
  cat(sprintf("  p-value                   : %.4f\n", x$p_value))
  
  # Décision statistique
  cat("\nDécision statistique :\n")
  cat("----------------------\n")
  if (x$p_value < 0.05) {
    cat("  ✓ Rejet de H0 (p < 0.05)\n")
    cat("    → La proportion observée diffère significativement de p0\n")
  } else {
    cat("  ✗ Non-rejet de H0 (p ≥ 0.05)\n")
    cat("    → Pas de différence significative avec p0\n")
  }
  
  # Interprétation LLM
  cat("\n============================================\n")
  cat("   Interprétation contextuelle (LLM)\n")
  cat("============================================\n\n")
  
  if (!is.null(x$interpretation)) {
    cat(strwrap(x$interpretation, width = 70), sep = "\n")
  } else {
    cat("  (Aucune interprétation générée)\n")
  }
  
  cat("\n============================================\n")
  
  invisible(x)
}


plot.context_proptest <- function(x, ...) {
  
  if (!requireNamespace("ggplot2", quietly = TRUE)) {
    stop("Le package 'ggplot2' est requis pour cette fonction")
  }
  if (!requireNamespace("scales", quietly = TRUE)) {
    stop("Le package 'scales' est requis pour cette fonction")
  }
  
  library(ggplot2)
  library(scales)
  
  # Créer le dataframe pour le graphique
  df <- data.frame(
    label    = c("Proportion observée", "Hypothèse nulle (p0)"),
    estimate = c(x$prop_estimee, x$p0),
    ic_inf   = c(x$ic_inf, NA),
    ic_sup   = c(x$ic_sup, NA)
  )
  
  # Déterminer la couleur selon la significativité
  couleur_obs <- if (x$p_value < 0.05) "firebrick" else "steelblue"
  
  # Créer le graphique
  p <- ggplot(df, aes(x = label, y = estimate)) +
    geom_col(
      fill = c(couleur_obs, "gray70"),
      alpha = 0.7,
      width = 0.6
    ) +
    geom_errorbar(
      aes(ymin = ic_inf, ymax = ic_sup),
      width = 0.2,
      linewidth = 1,
      na.rm = TRUE
    ) +
    geom_hline(
      yintercept = x$p0,
      linetype = "dashed",
      color = "red",
      linewidth = 0.8
    ) +
    scale_y_continuous(
      labels = percent,
      limits = c(0, max(1, x$ic_sup * 1.1))
    ) +
    labs(
      x = NULL,
      y = "Proportion",
      title = "Test de proportion avec intervalle de confiance",
      subtitle = sprintf(
        "p-value = %.4f | IC à %.0f%%",
        x$p_value,
        x$conf_level * 100
      ),
      caption = sprintf(
        "%d succès sur %d essais (%.1f%%)",
        x$x, x$n, x$prop_estimee * 100
      )
    ) +
    theme_minimal(base_size = 12) +
    theme(
      plot.title = element_text(face = "bold", size = 14),
      plot.subtitle = element_text(color = "gray40"),
      axis.text.x = element_text(size = 11),
      panel.grid.major.x = element_blank()
    )
  
  print(p)
  invisible(x)
}