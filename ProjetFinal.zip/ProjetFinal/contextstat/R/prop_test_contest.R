# fonction prop_test_context


prop_test_context <- function(x, n, p0 = 0.5, conf_level = 0.95,
                              context = NULL, model = "mistral") {

  # Validation des entrées

  if (!is.numeric(x) || !is.numeric(n) || x < 0 || n <= 0 || x > n) {
    stop("x et n doivent être des nombres positifs avec x <= n")
  }
  if (p0 <= 0 || p0 >= 1) {
    stop("p0 doit être entre 0 et 1 (exclus)")
  }
  if (conf_level <= 0 || conf_level >= 1) {
    stop("conf_level doit être entre 0 et 1 (exclus)")
  }

  # 1. Appel à prop.test() standard

  res <- prop.test(
    x = x,
    n = n,
    p = p0,
    conf.level = conf_level,
    correct = FALSE
  )

  # 2. Calculer la proportion estimée

  prop_estimee <- x / n

  # 3. Déterminer le contexte

  if (is.null(context)) {
    context <- sprintf(
      "Test de proportion avec hypothèse nulle p0 = %.2f",
      p0
    )
  }

  # 4. Créer le prompt pour le LLM

  prompt <- sprintf(
    "Contexte : %s

Résultats du test de proportion :
- Nombre d'essais (n) : %d
- Nombre de succès (x) : %d
- Proportion observée : %.2f%%%% (%.4f)
- Hypothèse nulle (p0) : %.2f%%%%
- p-value : %.4f
- Intervalle de confiance à %.0f%%%% : [%.4f, %.4f]

Tâche : Interprète ces résultats en 3-4 phrases de manière claire et accessible.
Explique si la proportion observée est significativement différente de p0 et ce que cela signifie dans le contexte donné.
Utilise un langage simple et évite le jargon technique excessif.",
    context,
    n,
    x,
    prop_estimee * 100, prop_estimee,
    p0 * 100,
    res$p.value,
    conf_level * 100,
    res$conf.int[1], res$conf.int[2]
  )

  # 5. Appel au LLM pour générer l'interprétation

  interpretation <- tryCatch({
    call_llm(prompt = prompt, model = model, max_tokens = 500)
  }, error = function(e) {
    warning("Impossible de générer l'interprétation LLM : ", e$message)
    "Interprétation non disponible. Vérifiez qu'Ollama est lancé et que le modèle est installé."
  })

  # 6. Construire l'objet de sortie

  out <- list(
    x            = x,
    n            = n,
    p0           = p0,
    conf_level   = conf_level,
    prop_estimee = prop_estimee,
    p_value      = res$p.value,
    ic_inf       = res$conf.int[1],
    ic_sup       = res$conf.int[2],
    test_result  = res,
    context      = context,
    interpretation = interpretation
  )

  # 7. Assigner la classe S3

  class(out) <- "context_proptest"

  return(out)
}




























