# fonction prop_test_context

prop_test_context <- function(x, n, p0 = 0.5, conf_level = 0.95, context = NULL,
                              dataset = NULL, package = NULL, model = "Chat-GPT") {
  
  # 1. appel à prop.test()
  
  res <- prop.test(
    x = x,
    n = n,
    p = p0,
    conf.level = conf_level,
    correct = FALSE
  )
  
  # 2. calculer la proportion estimée
  
  prop_estimee <- x / n
  
  # 3. Créer le contexte si nécessaire
  
  if (is.null(context)) {
    context <- sprintf("Test de proportion avec p0 = %.2f", p0)
  }
  
  # 4. construire l'objet de sortie
  
  out <- list(
    x           = x,
    n           = n,
    p0          = p0,
    conf_level  = conf_level,
    prop_estimee = prop_estimee,
    p_value      = res$p.value,
    ic_inf       = res$conf.int[1],
    ic_sup       = res$conf.int[2],
    context      = context,           #AJOUTER
    interpretation = interpretation   #AJOUTER
  )
  
  # 5. lui donner une classe S3
  
  class(out) <- "context_proptest" #nom plus coherent !
  
  # 6. retourner l'objet
  return(out)
}


library(ggplot2)

# Méthode plot.context_table

plot.context_proptest <- function(x, ...) {
  # x est l'objet de classe "context_proptest"
  
  df <- data.frame(
    label   = "proportion",
    estimate = x$prop_estimee,
    ic_inf   = x$ic_inf,
    ic_sup   = x$ic_sup
  )
  
  ggplot2::ggplot(df, ggplot2::aes(x = label, y = estimate)) +
    ggplot2::geom_point() +
    ggplot2::geom_errorbar(
      ggplot2::aes(ymin = ic_inf, ymax = ic_sup),
      width = 0.1
    ) +
    ggplot2::coord_cartesian(ylim = c(0, 1)) +
    ggplot2::labs(
      x = NULL,
      y = "Proportion",
      title = "Résultat du test de proportion"
    )
}

obj <- prop_test_context(12, 20, p0 = 0.5)

plot(obj)   # appelle plot.context_proptest(obj)

# Méthode print de prop_test_context  :

print.context_proptest <- function(x, ...) {
  
  cat("=== Test de proportion  ===\n\n")
  
  # Contexte
  if (!is.null(x$context)) {
    cat("Contexte:", x$context, "\n\n")
  }
  
  # Résultats 
  cat(sprintf("Proportion observée : %.2f%% (%d/%d)\n", 
              x$prop_estimee * 100, x$x, x$n))
  cat(sprintf("Hypothèse nulle     : %.2f%%\n", x$p0 * 100))
  cat(sprintf("p-value             : %.4f\n", x$p_value))
  cat(sprintf("IC à %.0f%%          : [%.3f, %.3f]\n", 
              x$conf_level * 100, x$ic_inf, x$ic_sup))
  
  # Interprétation LLM
  cat("\n--- Interprétation contextuelle ---\n")
  cat(x$interpretation, "\n")
  
  invisible(x)
}
