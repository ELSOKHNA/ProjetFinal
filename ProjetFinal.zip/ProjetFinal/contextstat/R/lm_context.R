
lm_context <- function(formula, data, context = NULL, model = "mistral") {
  
  # 1. Effectuer la régression linéaire standard
  
  lm_model <- lm(formula, data = data)
  
  # 2. Extraire les statistiques clés
  
  summary_lm <- summary(lm_model)
  coefs <- summary_lm$coefficients
  r_squared <- summary_lm$r.squared
  adj_r_squared <- summary_lm$adj.r.squared
  f_stat <- summary_lm$fstatistic
  n_obs <- nobs(lm_model)
  
  # 3. Déterminer le contexte
  
  if (is.null(context)) {
    vars <- all.vars(formula)
    context <- sprintf(
      "Régression linéaire : %s en fonction de %s",
      vars[1], paste(vars[-1], collapse = ", ")
    )
  }
  
  # 4. Créer le prompt pour le LLM
  
  coefs_text <- capture.output(print(coefs))
  coefs_formatted <- paste(coefs_text, collapse = "\n")
  
  prompt <- sprintf(
    "Contexte : %s

Résultats de la régression linéaire :
- Nombre d'observations : %d
- R² : %.4f (%.2f%%%% de variance expliquée)
- R² ajusté : %.4f
- Statistique F : %.2f (p-value : %.4e)

Coefficients estimés :
%s

Tâche : Interprète ces résultats en 4-5 phrases de manière claire et accessible.
Explique la qualité de l'ajustement (R²), la significativité globale du modèle,
et l'effet des variables explicatives. Utilise un langage simple.",
    context,
    n_obs,
    r_squared, r_squared * 100,
    adj_r_squared,
    f_stat[1],
    pf(f_stat[1], f_stat[2], f_stat[3], lower.tail = FALSE),
    coefs_formatted
  )
  
  # 5. Appel au LLM
  interpretation <- tryCatch({
    call_llm(prompt = prompt, model = model, max_tokens = 600)
  }, error = function(e) {
    warning("Impossible de générer l'interprétation LLM : ", e$message)
    "Interprétation non disponible. Vérifiez qu'Ollama est lancé."
  })
  
  # 6. Construire l'objet de sortie
  
  out <- list(
    model = lm_model,
    summary = summary_lm,
    context = context,
    interpretation = interpretation,
    formula = formula,
    data_name = deparse(substitute(data))
  )
  
  class(out) <- "context_lm"
  
  return(out)
}